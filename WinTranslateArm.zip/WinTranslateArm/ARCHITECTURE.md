# Architecture

## Pipeline

```mermaid
flowchart LR
    EXE[.exe file] --> PE[PE Loader]
    PE --> CPU[x86 / x86_64 -> ARM64 translation]
    CPU --> WINAPI[WinAPI compat layer]
    WINAPI --> SYS[Linux / Android syscalls]
    SYS --> ARM[ARM64 Android]

    BAT[.bat file] --> CMD[CMD interpreter]
    CMD --> WINAPI
```

## Status by subsystem

| Subsystem | Status | Notes |
|---|---|---|
| PE header parsing | **Working** | `cpp/pe/pe_loader.cpp`. DOS/COFF/Optional headers + section table, bounds-checked against untrusted input. |
| PE section mapping / imports / relocations | Not implemented | Would be needed before any code from the EXE could actually run. |
| CMD/BAT interpreter | **Working (subset)** | `cmd/CmdInterpreter.kt`. Real file I/O via `VirtualFileSystem`, no `Runtime.exec()`. `for` and `call` not implemented; `if` only supports `if exist <file> <command>`. |
| Virtual filesystem (`C:\`) | **Working** | `fs/VirtualFileSystem.kt`. Sandboxed under app-private storage. `D:\` (SAF-attached folder) not implemented. |
| Kotlin <-> JNI <-> C++ bridge | **Working** | `native/NativeBridge.kt` <-> `cpp/jni/native_lib.cpp`. Round-trips on every EXE inspection and at app startup. |
| CPU translation engine | **Stub** | `cpp/translator/translation_engine.h`. `execute()` always returns `NotImplemented`. See below. |
| WinAPI compatibility shim | Not implemented | No Win32 API surface is implemented yet. |
| Application profiles | **Data model only** | `core/ApplicationProfile.kt` has `toJson`/`fromJson`; nothing persists or loads them yet, so the Applications screen is empty. |
| Process list | **Working (in-memory)** | `core/ProcessManager.kt` tracks `WindowsProcess` entries for the current session only; nothing persists across restarts. |
| Settings | **Working** | `core/Settings.kt`, backed by `SharedPreferences`. |

## Why the translator is a stub

A real x86/x86_64 -> ARM64 CPU translation backend -- dynamic recompilation,
register/flag emulation, memory model handling, and so on -- is a
multi-year engineering effort in its own right (see Box64 and FEX-Emu,
both real open-source projects doing exactly this). Faking that layer
would mean either silently no-opping user programs or hard-coding
behavior for a handful of toy binaries, both of which would misrepresent
what the app does. Per this project's own requirements, functionality is
not faked: `StubTranslationEngine::execute()` always returns
`NotImplemented`, and the UI says so plainly (see
`ExecutableInfoScreen.kt`) instead of pretending a program ran.

[Winlator](https://winlator.org) is a real, actively maintained open-source
Android app that already combines Wine with Box86/Box64 and a Vulkan
driver (Turnip) to run Windows apps and games on Android -- it's cited
here as existing proof that this kind of pipeline works end-to-end on
Android, and as a reference for how the pieces fit together.

## Third-party project references (not bundled, not linked)

No third-party translation code is included in this project yet. These
are cited only as candidate backends for the "wire in a real engine"
step below:

| Project | Purpose | License |
|---|---|---|
| Box64 | x86_64 -> ARM64 dynamic binary translation | MIT |
| FEX-Emu | x86/x86_64 -> ARM64 dynamic binary translation | MIT (core); some bundled third-party components under BSL-1.0 / BSD-2-Clause |
| Wine | Win32 API compatibility layer | LGPL-2.1 |
| Winlator | Existing Android app combining the above | Open source (see its own repository for exact terms) |

## Security model

- Every picked EXE/BAT is treated as untrusted input. PE parsing is
  bounds-checked against the buffer size at every read. The CMD
  interpreter only ever touches files under the sandboxed virtual
  filesystem root.
- No `Runtime.exec()`, no shelling out, anywhere in this project.
- The app requests no `INTERNET` permission and does not talk to the
  network.
- As with any tool that runs third-party software, only run programs you
  have the rights to use.

## Next steps

1. Wire a real backend behind `ITranslationEngine` (Box64 and FEX-Emu are
   the realistic starting points).
2. Implement PE section mapping, import resolution, and base relocations
   in the loader.
3. Build a minimal WinAPI shim, starting with `GetStdHandle`,
   `WriteFile`, and `ExitProcess`.
4. Implement `for` and `call` in the CMD interpreter.
5. Persist `ApplicationProfile`s and build out the Applications screen
   against real saved data.
6. Implement `D:\` via an SAF folder picker.
