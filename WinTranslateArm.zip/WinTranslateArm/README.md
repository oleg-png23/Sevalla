# WinTranslate

A native Android (Kotlin + NDK/C++) app that lays the groundwork for running
Windows `.exe` and `.bat` files on ARM64 devices, via a PE-loader ->
CPU-translation -> WinAPI-compat -> Android pipeline. UI is inspired by
MIUI/HyperOS's rounded-card visual language (original palette and shapes --
not Xiaomi's actual brand assets, and this project has no affiliation with
Xiaomi).

## What actually works right now

- **EXE inspection is real.** Picking a `.exe` file hands its bytes to a
  native (C++) PE header parser that validates the DOS/PE signatures,
  reads the COFF and Optional headers, and walks the section table --
  all bounds-checked against untrusted input. It correctly reports
  architecture (x86 / x86_64 / ARM64), entry point RVA, image size, and
  section count, and cleanly rejects malformed or non-PE files.
- **BAT execution is real.** Picking a `.bat` file runs it through a
  genuine CMD interpreter (`echo`, `set`, `cd`, `dir`, `copy`, `move`,
  `del`, `mkdir`, `rmdir`, `type`, `where`, a limited `if exist`, etc.)
  against a sandboxed virtual `C:\` backed by real file I/O under the
  app's private storage. There is no `Runtime.exec()` anywhere in this
  project.
- **The Kotlin <-> JNI <-> C++ bridge is fully wired and round-trips** --
  `NativeBridge` calls into `libwintranslate.so` for PE parsing and for
  the translation engine's init/execute lifecycle, and the app logs the
  real result codes coming back from native code at startup.

## What's intentionally a stub

The actual x86/x86_64 -> ARM64 CPU translation engine
(`ITranslationEngine` / `StubTranslationEngine` in
`cpp/translator/translation_engine.h`) is an honest stub: it tracks
configuration and initialization state correctly, but `execute()` always
returns `NotImplemented` rather than pretending to run translated code.
Building a real CPU translation backend (something in the spirit of
Box64 or FEX-Emu, both MIT-licensed) is a substantial undertaking in its
own right -- see `ARCHITECTURE.md` for the reasoning, the current status
of every subsystem, and the roadmap for wiring a real backend in.

## Build

- Requires Android Studio with the NDK and CMake components installed.
- `minSdk` 26, `arm64-v8a` only.
- Open the project root in Android Studio and let Gradle sync; the native
  build is wired through `externalNativeBuild { cmake { ... } }` in
  `app/build.gradle.kts`.
- **This project hasn't been compiled in the sandbox it was generated
  in** (no Android SDK/NDK or network access there) -- treat your first
  build as the real first compile, and expect to fix small things like
  version bumps or an icon reference if your local SDK/NDK versions
  differ from what's pinned here.

## Project layout

```
app/src/main/java/com/wintranslate/arm/
  core/      data models, ProcessManager, Settings, TranslationEngine
  fs/        VirtualFileSystem (sandboxed virtual C:\)
  cmd/       CmdInterpreter (real BAT/CMD execution)
  native/    NativeBridge (JNI)
  io/        FilePicker (SAF document picker launchers)
  ui/        theme + screens (Compose)
app/src/main/cpp/
  pe/        PE header parsing (pe_format.h, pe_loader.h/.cpp)
  translator/ ITranslationEngine + honest stub
  jni/       native_lib.cpp (JNI exports)
```

See `ARCHITECTURE.md` for the full pipeline diagram, a subsystem-by-
subsystem status table, and next steps.
