package com.wintranslate.arm

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.wintranslate.arm.core.Logger
import com.wintranslate.arm.core.NativeTranslationEngine
import com.wintranslate.arm.core.PeInspectionResult
import com.wintranslate.arm.core.ProcessManager
import com.wintranslate.arm.core.Settings
import com.wintranslate.arm.core.TranslationConfig
import com.wintranslate.arm.io.FilePicker
import com.wintranslate.arm.ui.screens.ApplicationsScreen
import com.wintranslate.arm.ui.screens.BatOutputScreen
import com.wintranslate.arm.ui.screens.ExecutableInfoScreen
import com.wintranslate.arm.ui.screens.HomeScreen
import com.wintranslate.arm.ui.screens.ProcessesScreen
import com.wintranslate.arm.ui.screens.SettingsScreen
import com.wintranslate.arm.ui.theme.WinTranslateTheme

private enum class Screen {
    HOME, APPLICATIONS, PROCESSES, SETTINGS, EXE_RESULT, BAT_RESULT
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WinTranslateTheme {
                AppRoot(applicationContext)
            }
        }
    }
}

@Composable
private fun AppRoot(context: Context) {
    val processManager = remember { ProcessManager(context) }
    val translationEngine = remember { NativeTranslationEngine() }
    val settings = remember { Settings(context) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var exeResult by remember { mutableStateOf<PeInspectionResult?>(null) }
    var batOutput by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val result = translationEngine.initialize(TranslationConfig())
        Logger.i("MainActivity", "translationEngine.initialize() -> $result")
    }

    val launchExe = FilePicker.rememberExeLauncher { uri ->
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        if (bytes == null) return@rememberExeLauncher
        exeResult = processManager.inspectExecutable(bytes, uri.lastPathSegment ?: "unknown.exe")
        screen = Screen.EXE_RESULT
    }

    val launchBat = FilePicker.rememberBatLauncher { uri ->
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        if (bytes == null) return@rememberBatLauncher
        batOutput = processManager.runBatScript(bytes, uri.lastPathSegment ?: "unknown.bat")
        screen = Screen.BAT_RESULT
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        when (screen) {
            Screen.HOME -> HomeScreen(
                onOpenExe = launchExe,
                onOpenBat = launchBat,
                onOpenApplications = { screen = Screen.APPLICATIONS },
                onOpenProcesses = { screen = Screen.PROCESSES },
                onOpenSettings = { screen = Screen.SETTINGS }
            )
            Screen.APPLICATIONS -> ApplicationsScreen(onBack = { screen = Screen.HOME })
            Screen.PROCESSES -> ProcessesScreen(
                processes = processManager.processes,
                onBack = { screen = Screen.HOME }
            )
            Screen.SETTINGS -> SettingsScreen(settings = settings, onBack = { screen = Screen.HOME })
            Screen.EXE_RESULT -> ExecutableInfoScreen(result = exeResult, onBack = { screen = Screen.HOME })
            Screen.BAT_RESULT -> BatOutputScreen(output = batOutput, onBack = { screen = Screen.HOME })
        }
    }
}
