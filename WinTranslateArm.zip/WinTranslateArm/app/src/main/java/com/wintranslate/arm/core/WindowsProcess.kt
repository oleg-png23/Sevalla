package com.wintranslate.arm.core

enum class ProcessState {
    CREATED,
    STARTING,
    RUNNING,
    STOPPING,
    EXITED,
    FAILED
}

data class WindowsProcess(
    val pid: Int,
    val executable: String,
    val arguments: List<String> = emptyList(),
    val environment: Map<String, String> = emptyMap(),
    val workingDirectory: String = "C:\\",
    val architecture: Architecture = Architecture.UNKNOWN,
    val state: ProcessState = ProcessState.CREATED,
    val exitCode: Int? = null
)
