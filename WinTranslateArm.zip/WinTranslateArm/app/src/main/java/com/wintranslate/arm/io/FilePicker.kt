package com.wintranslate.arm.io

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable

object FilePicker {

    private val EXE_MIME_TYPES = arrayOf(
        "application/vnd.microsoft.portable-executable",
        "application/octet-stream",
        "*/*"
    )

    private val BAT_MIME_TYPES = arrayOf(
        "text/plain",
        "*/*"
    )

    @Composable
    fun rememberExeLauncher(onPicked: (Uri) -> Unit) =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) onPicked(uri)
        }.let { launcher ->
            { launcher.launch(EXE_MIME_TYPES) }
        }

    @Composable
    fun rememberBatLauncher(onPicked: (Uri) -> Unit) =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) onPicked(uri)
        }.let { launcher ->
            { launcher.launch(BAT_MIME_TYPES) }
        }
}
