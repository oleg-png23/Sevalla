package com.wintranslate.arm.fs

import android.content.Context
import java.io.File

/**
 * A sandboxed virtual Windows filesystem rooted at app-private storage.
 *
 * "C:\" maps to <filesDir>/winroot. All paths are resolved against that
 * root so a translated program can never read or write outside the
 * app's own sandbox, regardless of what path it requests.
 *
 * D:\ (an SAF-attached user folder) is not implemented yet -- see
 * ARCHITECTURE.md.
 */
class VirtualFileSystem(context: Context) {

    private val root: File = File(context.filesDir, "winroot")

    private val windowsDir = File(root, "Windows")
    private val programFilesDir = File(root, "Program Files")
    private val usersDefaultDir = File(root, "Users/Default")

    var currentDirectory: String = "C:\\"
        private set

    init {
        root.mkdirs()
        windowsDir.mkdirs()
        programFilesDir.mkdirs()
        usersDefaultDir.mkdirs()
    }

    fun windowsRootDir(): File = root
    fun windowsDir(): File = windowsDir
    fun programFilesDir(): File = programFilesDir
    fun usersDefaultDir(): File = usersDefaultDir

    /** Converts a Windows-style path (e.g. "C:\Windows\System32") to a host File. */
    fun toHostPath(windowsPath: String): File {
        val stripped = if (windowsPath.length >= 2 &&
            windowsPath[1] == ':' &&
            windowsPath.take(2).equals("C:", ignoreCase = true)
        ) {
            windowsPath.drop(2)
        } else {
            windowsPath
        }
        val normalized = stripped.replace('\\', '/').trimStart('/')
        return if (normalized.isEmpty()) root else File(root, normalized)
    }

    /**
     * Resolves a path relative to [base] (defaults to the current directory),
     * handling "." and ".." the way CMD does.
     */
    fun resolve(path: String, base: String = currentDirectory): String {
        if (path == ".") return base
        if (path == "..") {
            val trimmed = base.trimEnd('\\')
            val idx = trimmed.lastIndexOf('\\')
            return if (idx <= 2) "C:\\" else trimmed.substring(0, idx) + "\\"
        }
        if (path.length >= 2 && path[1] == ':') {
            // Absolute path already.
            return if (path.endsWith("\\")) path else "$path\\"
        }
        val baseNormalized = if (base.endsWith("\\")) base else "$base\\"
        val combined = baseNormalized + path
        return if (combined.endsWith("\\")) combined else "$combined\\"
    }

    fun changeDirectory(target: String): Boolean {
        val resolved = resolve(target)
        val hostDir = toHostPath(resolved)
        if (!hostDir.exists() || !hostDir.isDirectory) return false
        currentDirectory = resolved
        return true
    }

    fun list(path: String = currentDirectory): List<File> {
        val hostDir = toHostPath(path)
        return hostDir.listFiles()?.toList() ?: emptyList()
    }
}
