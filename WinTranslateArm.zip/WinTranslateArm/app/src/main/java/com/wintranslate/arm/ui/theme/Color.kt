package com.wintranslate.arm.ui.theme

import androidx.compose.ui.graphics.Color

// Original palette inspired by MIUI/HyperOS -- not Xiaomi's actual brand assets.
val MiOrange = Color(0xFFFF6900)
val MiOrangeDark = Color(0xFFE85D00)
val MiOrangeLight = Color(0xFFFFE4CC)

val MiBackgroundLight = Color(0xFFF7F7F7)
val MiSurfaceLight = Color(0xFFFFFFFF)
val MiOnSurfaceLight = Color(0xFF1C1C1E)

val MiBackgroundDark = Color(0xFF121212)
val MiSurfaceDark = Color(0xFF1E1E1E)
val MiOnSurfaceDark = Color(0xFFF2F2F2)

val MiSuccess = Color(0xFF34C759)
val MiWarning = Color(0xFFFFB800)
val MiError = Color(0xFFFF3B30)
val MiTextSecondary = Color(0xFF8E8E93)
