package com.wintranslate.arm.cmd

import com.wintranslate.arm.core.Logger
import com.wintranslate.arm.fs.VirtualFileSystem

/**
 * A minimal but genuinely-executing CMD/BAT interpreter. Every command below
 * runs real java.io.File operations against [vfs]'s sandboxed root -- there
 * is no Runtime.exec() anywhere in this class.
 *
 * Known limitations (see ARCHITECTURE.md for the full list):
 *  - `if` only supports the "if exist <file> <command>" form.
 *  - `for` and `call` are not implemented.
 *  - `exit` inside a nested `if` is not caught by the top-level loop break,
 *    only by the no-op fallback below.
 */
class CmdInterpreter(private val vfs: VirtualFileSystem) {

    private val variables = mutableMapOf<String, String>()
    private var echo = true
    val output = StringBuilder()

    fun runScript(lines: List<String>) {
        for (rawLine in lines) {
            val expanded = expandVariables(rawLine)
            val trimmed = expanded.trim()
            if (trimmed.isEmpty()) continue

            val silent = trimmed.startsWith("@")
            val command = if (silent) trimmed.drop(1).trim() else trimmed

            if (command.equals("echo off", ignoreCase = true)) {
                echo = false
                continue
            }
            if (command.equals("echo on", ignoreCase = true)) {
                echo = true
                continue
            }

            if (echo && !silent) {
                emit("${vfs.currentDirectory}> $command")
            }

            if (command.equals("exit", ignoreCase = true) || command.startsWith("exit ", ignoreCase = true)) {
                runLine(command)
                break
            }

            runLine(command)
        }
    }

    fun runLine(command: String) {
        val tokens = tokenize(command)
        if (tokens.isEmpty()) return
        val cmd = tokens[0].lowercase()
        val args = tokens.drop(1)

        when (cmd) {
            "echo" -> doEcho(args)
            "set" -> doSet(args)
            "cd", "chdir" -> doCd(args)
            "dir" -> doDir(args)
            "copy" -> doCopy(args)
            "move" -> doMove(args)
            "del", "erase" -> doDel(args)
            "mkdir", "md" -> doMkdir(args)
            "rmdir", "rd" -> doRmdir(args)
            "type" -> doType(args)
            "cls" -> { /* no-op: nothing to clear in a captured-output interpreter */ }
            "where" -> doWhere(args)
            "pause" -> emit("Press any key to continue . . .")
            "exit" -> { /* handled by caller; no-op if reached via nested control flow */ }
            "path" -> emit(variables["PATH"] ?: "")
            "if" -> doIf(args)
            else -> fail("'$cmd' is not recognized as an internal or external command.")
        }
        variables["ERRORLEVEL"] = errorLevel.toString()
    }

    private var errorLevel = 0

    // ---- command handlers -------------------------------------------------

    private fun doEcho(args: List<String>) {
        emit(args.joinToString(" "))
        errorLevel = 0
    }

    private fun doSet(args: List<String>) {
        if (args.isEmpty()) {
            for ((k, v) in variables) emit("$k=$v")
            errorLevel = 0
            return
        }
        val joined = args.joinToString(" ")
        val eq = joined.indexOf('=')
        if (eq < 0) {
            val value = variables[joined]
            if (value != null) emit("$joined=$value") else fail("Environment variable $joined not defined")
            return
        }
        val key = joined.substring(0, eq)
        val value = joined.substring(eq + 1)
        variables[key] = value
        errorLevel = 0
    }

    private fun doCd(args: List<String>) {
        if (args.isEmpty()) {
            emit(vfs.currentDirectory)
            errorLevel = 0
            return
        }
        val target = args.joinToString(" ")
        if (vfs.changeDirectory(target)) {
            errorLevel = 0
        } else {
            fail("The system cannot find the path specified.")
        }
    }

    private fun doDir(args: List<String>) {
        val path = if (args.isEmpty()) vfs.currentDirectory else vfs.resolve(args.joinToString(" "))
        val entries = vfs.list(path)
        emit(" Directory of $path")
        emit("")
        for (entry in entries) {
            val marker = if (entry.isDirectory) "<DIR>" else "     "
            emit("  $marker  ${entry.name}")
        }
        emit("")
        emit("${entries.count { it.isFile }} File(s)")
        emit("${entries.count { it.isDirectory }} Dir(s)")
        errorLevel = 0
    }

    private fun doCopy(args: List<String>) {
        if (args.size < 2) { fail("The syntax of the command is incorrect."); return }
        val src = vfs.toHostPath(vfs.resolve(args[0]))
        val dst = vfs.toHostPath(vfs.resolve(args[1]))
        if (!src.exists() || !src.isFile) { fail("The system cannot find the file specified."); return }
        try {
            src.copyTo(dst, overwrite = true)
            emit("        1 file(s) copied.")
            errorLevel = 0
        } catch (t: Throwable) {
            fail("Could not copy file: ${t.message}")
        }
    }

    private fun doMove(args: List<String>) {
        if (args.size < 2) { fail("The syntax of the command is incorrect."); return }
        val src = vfs.toHostPath(vfs.resolve(args[0]))
        val dst = vfs.toHostPath(vfs.resolve(args[1]))
        if (!src.exists()) { fail("The system cannot find the file specified."); return }
        if (src.renameTo(dst)) {
            emit("        1 file(s) moved.")
            errorLevel = 0
        } else {
            fail("Could not move file.")
        }
    }

    private fun doDel(args: List<String>) {
        if (args.isEmpty()) { fail("The syntax of the command is incorrect."); return }
        val target = vfs.toHostPath(vfs.resolve(args.joinToString(" ")))
        if (!target.exists() || !target.isFile) { fail("Could not find file"); return }
        if (target.delete()) errorLevel = 0 else fail("Could not delete file")
    }

    private fun doMkdir(args: List<String>) {
        if (args.isEmpty()) { fail("The syntax of the command is incorrect."); return }
        val target = vfs.toHostPath(vfs.resolve(args.joinToString(" ")))
        if (target.mkdirs()) errorLevel = 0 else fail("A subdirectory or file already exists.")
    }

    private fun doRmdir(args: List<String>) {
        if (args.isEmpty()) { fail("The syntax of the command is incorrect."); return }
        val target = vfs.toHostPath(vfs.resolve(args.joinToString(" ")))
        if (!target.exists() || !target.isDirectory) { fail("The system cannot find the file specified."); return }
        if (target.delete()) errorLevel = 0 else fail("The directory is not empty.")
    }

    private fun doType(args: List<String>) {
        if (args.isEmpty()) { fail("The syntax of the command is incorrect."); return }
        val target = vfs.toHostPath(vfs.resolve(args.joinToString(" ")))
        if (!target.exists() || !target.isFile) { fail("The system cannot find the file specified."); return }
        emit(target.readText())
        errorLevel = 0
    }

    private fun doWhere(args: List<String>) {
        if (args.isEmpty()) { fail("The syntax of the command is incorrect."); return }
        val name = args[0]
        val found = vfs.list(vfs.currentDirectory).firstOrNull { it.name.equals(name, ignoreCase = true) }
        if (found != null) {
            emit(vfs.currentDirectory + name)
            errorLevel = 0
        } else {
            fail("INFO: Could not find files for the given pattern(s).")
        }
    }

    private fun doIf(args: List<String>) {
        // Only "if exist <file> <command...>" is supported.
        if (args.size >= 3 && args[0].equals("exist", ignoreCase = true)) {
            val target = vfs.toHostPath(vfs.resolve(args[1]))
            if (target.exists()) {
                runLine(args.drop(2).joinToString(" "))
            } else {
                errorLevel = 0
            }
            return
        }
        fail("Unsupported IF form (only 'if exist <file> <command>' is implemented).")
    }

    // ---- helpers ------------------------------------------------------

    private fun expandVariables(line: String): String {
        var result = line.replace("%CD%", vfs.resolve("."), ignoreCase = true)
        result = Regex("%([A-Za-z0-9_]+)%").replace(result) { match ->
            val name = match.groupValues[1]
            variables[name] ?: match.value
        }
        return result
    }

    private fun tokenize(command: String): List<String> {
        val tokens = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        for (c in command) {
            when {
                c == '"' -> inQuotes = !inQuotes
                c.isWhitespace() && !inQuotes -> {
                    if (current.isNotEmpty()) {
                        tokens.add(current.toString())
                        current.clear()
                    }
                }
                else -> current.append(c)
            }
        }
        if (current.isNotEmpty()) tokens.add(current.toString())
        return tokens
    }

    private fun fail(message: String) {
        errorLevel = 1
        emit(message)
    }

    private fun emit(line: String) {
        output.append(line).append('\n')
        Logger.i("CMD", line)
    }
}
