package com.wintranslate.arm.core

enum class TranslationMode {
    FAST,
    BALANCED,
    COMPATIBILITY
}
