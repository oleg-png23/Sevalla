package com.wintranslate.arm.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wintranslate.arm.core.Settings
import com.wintranslate.arm.core.TranslationMode

@Composable
fun SettingsScreen(settings: Settings, onBack: () -> Unit) {
    var translationMode by remember { mutableStateOf(settings.translationMode) }
    var diskCacheEnabled by remember { mutableStateOf(settings.diskCacheEnabled) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        ScreenHeader("Settings", onBack)

        Text("Translation mode", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(4.dp))

        TranslationMode.values().forEach { mode ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = translationMode == mode,
                        onClick = {
                            translationMode = mode
                            settings.translationMode = mode
                        }
                    )
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = translationMode == mode,
                    onClick = {
                        translationMode = mode
                        settings.translationMode = mode
                    }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(mode.name.lowercase().replaceFirstChar { it.uppercase() })
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Disk cache enabled", style = MaterialTheme.typography.titleMedium)
            Switch(
                checked = diskCacheEnabled,
                onCheckedChange = {
                    diskCacheEnabled = it
                    settings.diskCacheEnabled = it
                }
            )
        }
    }
}
