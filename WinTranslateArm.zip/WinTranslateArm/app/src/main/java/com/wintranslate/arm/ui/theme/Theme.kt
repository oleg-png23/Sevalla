package com.wintranslate.arm.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = MiOrange,
    onPrimary = Color.White,
    primaryContainer = MiOrangeLight,
    onPrimaryContainer = MiOrangeDark,
    background = MiBackgroundLight,
    surface = MiSurfaceLight,
    onBackground = MiOnSurfaceLight,
    onSurface = MiOnSurfaceLight,
    error = MiError
)

private val DarkColors = darkColorScheme(
    primary = MiOrange,
    onPrimary = Color.White,
    primaryContainer = MiOrangeDark,
    onPrimaryContainer = MiOrangeLight,
    background = MiBackgroundDark,
    surface = MiSurfaceDark,
    onBackground = MiOnSurfaceDark,
    onSurface = MiOnSurfaceDark,
    error = MiError
)

@Composable
fun WinTranslateTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        shapes = MiShapes,
        typography = MiTypography,
        content = content
    )
}
