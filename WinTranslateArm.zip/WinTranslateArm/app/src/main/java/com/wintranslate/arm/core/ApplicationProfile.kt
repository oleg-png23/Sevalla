package com.wintranslate.arm.core

import org.json.JSONArray
import org.json.JSONObject

data class ApplicationProfile(
    val executablePath: String,
    val arguments: List<String> = emptyList(),
    val workingDirectory: String = "C:\\",
    val environmentVariables: Map<String, String> = emptyMap(),
    val architecture: Architecture = Architecture.UNKNOWN,
    val graphicsMode: String = "none",
    val audioMode: String = "none",
    val memoryLimitMb: Int = 0,
    val translationMode: TranslationMode = TranslationMode.BALANCED,
    val cacheEnabled: Boolean = true
) {
    fun toJson(): String {
        val obj = JSONObject()
        obj.put("executablePath", executablePath)
        obj.put("arguments", JSONArray(arguments))
        obj.put("workingDirectory", workingDirectory)
        obj.put("environmentVariables", JSONObject(environmentVariables))
        obj.put("architecture", architecture.name)
        obj.put("graphicsMode", graphicsMode)
        obj.put("audioMode", audioMode)
        obj.put("memoryLimitMb", memoryLimitMb)
        obj.put("translationMode", translationMode.name)
        obj.put("cacheEnabled", cacheEnabled)
        return obj.toString()
    }

    companion object {
        fun fromJson(json: String): ApplicationProfile {
            val obj = JSONObject(json)
            val argsArray = obj.optJSONArray("arguments") ?: JSONArray()
            val args = (0 until argsArray.length()).map { argsArray.getString(it) }

            val envObj = obj.optJSONObject("environmentVariables") ?: JSONObject()
            val env = envObj.keys().asSequence().associateWith { key -> envObj.getString(key) }

            return ApplicationProfile(
                executablePath = obj.getString("executablePath"),
                arguments = args,
                workingDirectory = obj.optString("workingDirectory", "C:\\"),
                environmentVariables = env,
                architecture = Architecture.fromNative(obj.optString("architecture", "UNKNOWN")),
                graphicsMode = obj.optString("graphicsMode", "none"),
                audioMode = obj.optString("audioMode", "none"),
                memoryLimitMb = obj.optInt("memoryLimitMb", 0),
                translationMode = runCatching {
                    TranslationMode.valueOf(obj.optString("translationMode", "BALANCED"))
                }.getOrDefault(TranslationMode.BALANCED),
                cacheEnabled = obj.optBoolean("cacheEnabled", true)
            )
        }
    }
}
