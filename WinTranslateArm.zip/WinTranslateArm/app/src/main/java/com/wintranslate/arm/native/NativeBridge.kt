package com.wintranslate.arm.native

/**
 * Thin JNI bridge into libwintranslate.so. All real work (PE parsing,
 * translation engine lifecycle) happens in native C++ -- see
 * app/src/main/cpp/jni/native_lib.cpp for the matching exports.
 */
object NativeBridge {

    init {
        System.loadLibrary("wintranslate")
    }

    /** Parses a PE header from [data] and returns the result as a JSON string. */
    external fun inspectPe(data: ByteArray): String

    /** Initializes the native translation engine. Returns an EngineResult code. */
    external fun engineInitialize(): Int

    /** Asks the native translation engine to execute [binaryPath]. Returns an EngineResult code. */
    external fun engineExecute(binaryPath: String): Int
}
