package com.wintranslate.arm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wintranslate.arm.core.PeInspectionResult

@Composable
fun ExecutableInfoScreen(result: PeInspectionResult?, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        ScreenHeader("Executable Info", onBack)

        when {
            result == null -> {
                Text(
                    "No file inspected.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            !result.valid -> {
                Text(
                    "This file could not be parsed as a valid PE executable" +
                        (result.error?.let { ": $it" } ?: "."),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }
            else -> {
                Card(shape = MaterialTheme.shapes.medium) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        InfoRow("Architecture", result.architecture.name)
                        InfoRow("Entry point RVA", "0x${result.entryPointRva.toString(16)}")
                        InfoRow("Size of image", "${result.sizeOfImage} bytes")
                        InfoRow("Section count", result.sectionCount.toString())
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    "Running this program isn't possible yet -- WinTranslate can read " +
                        "its PE header, but the CPU translation engine is an honest stub " +
                        "with no backend wired in. See ARCHITECTURE.md for the current " +
                        "status and roadmap.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}
