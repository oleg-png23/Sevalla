package com.wintranslate.arm.core

enum class Architecture {
    UNKNOWN,
    X86,
    X86_64,
    ARM64;

    companion object {
        fun fromNative(value: String): Architecture = when (value.uppercase()) {
            "X86" -> X86
            "X86_64" -> X86_64
            "ARM64" -> ARM64
            else -> UNKNOWN
        }
    }
}
