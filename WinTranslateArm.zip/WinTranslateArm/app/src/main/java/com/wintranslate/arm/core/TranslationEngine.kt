package com.wintranslate.arm.core

import com.wintranslate.arm.native.NativeBridge

data class TranslationConfig(
    val mode: TranslationMode = TranslationMode.BALANCED,
    val cacheSizeMb: Int = 64,
    val diskCacheEnabled: Boolean = true
)

/**
 * Result codes mirror the native EngineResult enum (see translation_engine.h):
 * 0 = Ok, -1 = NotInitialized, -2 = UnsupportedArchitecture,
 * -3 = InvalidExecutable, -100 = NotImplemented.
 */
interface TranslationEngine {
    fun initialize(config: TranslationConfig): Int
    fun canExecute(architecture: Architecture): Boolean
    fun execute(binaryPath: String): Int
    fun terminate(pid: Int): Int
    fun shutdown(): Int
}

class NativeTranslationEngine : TranslationEngine {

    override fun initialize(config: TranslationConfig): Int {
        val result = NativeBridge.engineInitialize()
        Logger.i("TranslationEngine", "initialize() -> $result")
        return result
    }

    override fun canExecute(architecture: Architecture): Boolean {
        // Honest stub: no translation backend is wired in yet, so nothing
        // can actually execute. See ARCHITECTURE.md.
        return false
    }

    override fun execute(binaryPath: String): Int {
        val result = NativeBridge.engineExecute(binaryPath)
        Logger.i("TranslationEngine", "execute($binaryPath) -> $result")
        return result
    }

    override fun terminate(pid: Int): Int = 0

    override fun shutdown(): Int = 0
}
