package com.wintranslate.arm.core

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import com.wintranslate.arm.cmd.CmdInterpreter
import com.wintranslate.arm.fs.VirtualFileSystem
import com.wintranslate.arm.native.NativeBridge
import org.json.JSONObject

data class PeInspectionResult(
    val valid: Boolean,
    val architecture: Architecture,
    val entryPointRva: Long,
    val sizeOfImage: Long,
    val sectionCount: Int,
    val error: String?
)

class ProcessManager(context: Context) {

    val fileSystem = VirtualFileSystem(context)

    private val _processes = mutableStateListOf<WindowsProcess>()
    val processes: List<WindowsProcess> get() = _processes

    private var nextPid = 1000

    fun inspectExecutable(bytes: ByteArray, displayName: String): PeInspectionResult {
        val json = NativeBridge.inspectPe(bytes)
        val obj = JSONObject(json)

        val valid = obj.optBoolean("valid", false)
        val architecture = Architecture.fromNative(obj.optString("architecture", "UNKNOWN"))
        val entryPointRva = obj.optLong("entryPointRva", 0)
        val sizeOfImage = obj.optLong("sizeOfImage", 0)
        val sectionCount = obj.optInt("sectionCount", 0)
        val error = if (obj.has("error") && !obj.isNull("error")) obj.optString("error") else null

        val process = WindowsProcess(
            pid = nextPid++,
            executable = displayName,
            architecture = architecture,
            state = if (valid) ProcessState.CREATED else ProcessState.FAILED,
            exitCode = if (valid) null else -1
        )
        _processes.add(process)

        return PeInspectionResult(valid, architecture, entryPointRva, sizeOfImage, sectionCount, error)
    }

    fun runBatScript(bytes: ByteArray, displayName: String): String {
        val pid = nextPid++
        var process = WindowsProcess(
            pid = pid,
            executable = displayName,
            architecture = Architecture.UNKNOWN,
            state = ProcessState.RUNNING
        )
        _processes.add(process)
        val index = _processes.size - 1

        val interpreter = CmdInterpreter(fileSystem)
        val text = bytes.toString(Charsets.UTF_8)
        val lines = text.split("\r\n", "\n")

        return try {
            interpreter.runScript(lines)
            process = process.copy(state = ProcessState.EXITED, exitCode = 0)
            _processes[index] = process
            interpreter.output.toString()
        } catch (t: Throwable) {
            process = process.copy(state = ProcessState.FAILED, exitCode = 1)
            _processes[index] = process
            interpreter.output.toString() + "\n[error] ${t.message}"
        }
    }
}
