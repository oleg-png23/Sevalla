package com.wintranslate.arm.core

import android.util.Log

object Logger {

    private const val MAX_CHARS = 200_000
    private val buffer = StringBuilder()

    @Synchronized
    fun i(tag: String, message: String) {
        Log.i(tag, message)
        append("I", tag, message)
    }

    @Synchronized
    fun w(tag: String, message: String) {
        Log.w(tag, message)
        append("W", tag, message)
    }

    @Synchronized
    fun e(tag: String, message: String) {
        Log.e(tag, message)
        append("E", tag, message)
    }

    @Synchronized
    fun exportText(): String = buffer.toString()

    private fun append(level: String, tag: String, message: String) {
        buffer.append(level).append('/').append(tag).append(": ").append(message).append('\n')
        if (buffer.length > MAX_CHARS) {
            buffer.delete(0, buffer.length - MAX_CHARS)
        }
    }
}
