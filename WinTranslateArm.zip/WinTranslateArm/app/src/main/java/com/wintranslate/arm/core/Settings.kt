package com.wintranslate.arm.core

import android.content.Context
import android.content.SharedPreferences

class Settings(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("wintranslate_settings", Context.MODE_PRIVATE)

    var translationMode: TranslationMode
        get() = runCatching {
            TranslationMode.valueOf(prefs.getString(KEY_TRANSLATION_MODE, TranslationMode.BALANCED.name)!!)
        }.getOrDefault(TranslationMode.BALANCED)
        set(value) = prefs.edit().putString(KEY_TRANSLATION_MODE, value.name).apply()

    var cacheSizeMb: Int
        get() = prefs.getInt(KEY_CACHE_SIZE_MB, 64)
        set(value) = prefs.edit().putInt(KEY_CACHE_SIZE_MB, value).apply()

    var diskCacheEnabled: Boolean
        get() = prefs.getBoolean(KEY_DISK_CACHE_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_DISK_CACHE_ENABLED, value).apply()

    var darkTheme: Boolean
        get() = prefs.getBoolean(KEY_DARK_THEME, false)
        set(value) = prefs.edit().putBoolean(KEY_DARK_THEME, value).apply()

    companion object {
        private const val KEY_TRANSLATION_MODE = "translation_mode"
        private const val KEY_CACHE_SIZE_MB = "cache_size_mb"
        private const val KEY_DISK_CACHE_ENABLED = "disk_cache_enabled"
        private const val KEY_DARK_THEME = "dark_theme"
    }
}
