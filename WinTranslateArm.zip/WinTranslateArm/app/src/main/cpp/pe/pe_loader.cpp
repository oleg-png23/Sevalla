#include "pe_loader.h"
#include "pe_format.h"

#include <cstring>

namespace pe {

namespace {

// Reads a T at [offset, offset + sizeof(T)) from data, bounds-checked
// (including overflow-safe) against size. Returns false if the read would
// go out of bounds -- data is untrusted, so every read must be checked.
template <typename T>
bool readAt(const uint8_t* data, size_t size, size_t offset, T* out) {
    if (offset + sizeof(T) < offset) return false; // overflow
    if (offset + sizeof(T) > size) return false;   // out of bounds
    std::memcpy(out, data + offset, sizeof(T));
    return true;
}

Architecture architectureFromMachine(uint16_t machine) {
    switch (machine) {
        case MACHINE_I386:  return Architecture::X86;
        case MACHINE_AMD64: return Architecture::X86_64;
        case MACHINE_ARM64: return Architecture::Arm64;
        default:            return Architecture::Unknown;
    }
}

std::string sectionName(const char raw[8]) {
    size_t len = strnlen(raw, 8);
    return std::string(raw, len);
}

} // namespace

PeInfo parseHeaders(const uint8_t* data, size_t size) {
    PeInfo info;

    if (data == nullptr || size == 0) {
        info.error = "empty input";
        return info;
    }

    DosHeader dos{};
    if (!readAt(data, size, 0, &dos)) {
        info.error = "file too small for DOS header";
        return info;
    }
    if (dos.e_magic != DOS_MAGIC) {
        info.error = "missing MZ signature";
        return info;
    }
    if (dos.e_lfanew < 0) {
        info.error = "invalid e_lfanew";
        return info;
    }

    size_t peOffset = static_cast<size_t>(dos.e_lfanew);
    uint32_t peSignature = 0;
    if (!readAt(data, size, peOffset, &peSignature)) {
        info.error = "PE signature out of bounds";
        return info;
    }
    if (peSignature != PE_SIGNATURE) {
        info.error = "missing PE\\0\\0 signature";
        return info;
    }

    size_t coffOffset = peOffset + sizeof(uint32_t);
    CoffFileHeader coff{};
    if (!readAt(data, size, coffOffset, &coff)) {
        info.error = "COFF header out of bounds";
        return info;
    }

    info.architecture = architectureFromMachine(coff.machine);
    if (info.architecture == Architecture::Unknown) {
        info.error = "unrecognized machine type";
        return info;
    }
    info.numberOfSections = coff.numberOfSections;

    size_t optOffset = coffOffset + sizeof(CoffFileHeader);
    size_t sectionsOffset = 0;

    uint16_t optMagic = 0;
    if (!readAt(data, size, optOffset, &optMagic)) {
        info.error = "optional header out of bounds";
        return info;
    }

    if (optMagic == OPT_MAGIC_PE32) {
        OptionalHeader32 opt32{};
        if (!readAt(data, size, optOffset, &opt32)) {
            info.error = "PE32 optional header out of bounds";
            return info;
        }
        info.entryPointRva = opt32.addressOfEntryPoint;
        info.imageBase = opt32.imageBase;
        info.sizeOfImage = opt32.sizeOfImage;
        info.subsystem = opt32.subsystem;
        sectionsOffset = optOffset + coff.sizeOfOptionalHeader;
    } else if (optMagic == OPT_MAGIC_PE32PLUS) {
        OptionalHeader64 opt64{};
        if (!readAt(data, size, optOffset, &opt64)) {
            info.error = "PE32+ optional header out of bounds";
            return info;
        }
        info.entryPointRva = opt64.addressOfEntryPoint;
        info.imageBase = opt64.imageBase;
        info.sizeOfImage = opt64.sizeOfImage;
        info.subsystem = opt64.subsystem;
        sectionsOffset = optOffset + coff.sizeOfOptionalHeader;
    } else {
        info.error = "unrecognized optional header magic";
        return info;
    }

    for (uint32_t i = 0; i < coff.numberOfSections; ++i) {
        SectionHeader section{};
        size_t sectionOffset = sectionsOffset + static_cast<size_t>(i) * sizeof(SectionHeader);
        if (!readAt(data, size, sectionOffset, &section)) {
            // Truncated section table: stop here, keep what we already parsed.
            break;
        }
        SectionInfo sectionInfo;
        sectionInfo.name = sectionName(section.name);
        sectionInfo.virtualAddress = section.virtualAddress;
        sectionInfo.virtualSize = section.virtualSize;
        sectionInfo.rawSize = section.sizeOfRawData;
        sectionInfo.rawOffset = section.pointerToRawData;
        sectionInfo.characteristics = section.characteristics;
        info.sections.push_back(std::move(sectionInfo));
    }

    info.valid = true;
    return info;
}

} // namespace pe
