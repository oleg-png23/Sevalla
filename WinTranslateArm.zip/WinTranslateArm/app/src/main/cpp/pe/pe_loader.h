#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace pe {

enum class Architecture {
    Unknown,
    X86,
    X86_64,
    Arm64
};

struct SectionInfo {
    std::string name;
    uint32_t virtualAddress = 0;
    uint32_t virtualSize = 0;
    uint32_t rawSize = 0;
    uint32_t rawOffset = 0;
    uint32_t characteristics = 0;
};

struct PeInfo {
    bool valid = false;
    Architecture architecture = Architecture::Unknown;
    uint32_t entryPointRva = 0;
    uint64_t imageBase = 0;
    uint32_t sizeOfImage = 0;
    uint16_t subsystem = 0;
    uint32_t numberOfSections = 0;
    std::vector<SectionInfo> sections;
    std::string error;
};

// Parses the DOS/COFF/Optional headers and section table from a raw PE
// image buffer. This is header parsing ONLY: it does not map sections into
// memory, resolve imports, or apply base relocations. All reads are bounds-
// checked against [data, data + size) since the input is untrusted.
PeInfo parseHeaders(const uint8_t* data, size_t size);

} // namespace pe
