#include <jni.h>

#include <cstdio>
#include <sstream>
#include <string>
#include <vector>

#include "../common/log.h"
#include "../pe/pe_loader.h"
#include "../translator/translation_engine.h"

namespace {

// Single shared engine instance for the process lifetime.
engine::StubTranslationEngine g_engine;

const char* archName(pe::Architecture arch) {
    switch (arch) {
        case pe::Architecture::X86:    return "X86";
        case pe::Architecture::X86_64: return "X86_64";
        case pe::Architecture::Arm64:  return "ARM64";
        default:                       return "UNKNOWN";
    }
}

// Escapes a string for safe embedding in a hand-rolled JSON string value.
// Applied to both section names and error messages since both originate
// from untrusted PE input.
std::string jsonEscape(const std::string& in) {
    std::string out;
    out.reserve(in.size());
    for (char c : in) {
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\t': out += "\\t"; break;
            default:
                if (static_cast<unsigned char>(c) < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += c;
                }
        }
    }
    return out;
}

std::string toJson(const pe::PeInfo& info) {
    std::ostringstream json;
    json << "{";
    json << "\"valid\":" << (info.valid ? "true" : "false") << ",";
    json << "\"architecture\":\"" << archName(info.architecture) << "\",";
    json << "\"entryPointRva\":" << info.entryPointRva << ",";
    json << "\"imageBase\":" << info.imageBase << ",";
    json << "\"sizeOfImage\":" << info.sizeOfImage << ",";
    json << "\"subsystem\":" << info.subsystem << ",";
    json << "\"sectionCount\":" << info.sections.size() << ",";

    json << "\"sections\":[";
    for (size_t i = 0; i < info.sections.size(); ++i) {
        const auto& s = info.sections[i];
        if (i > 0) json << ",";
        json << "{"
             << "\"name\":\"" << jsonEscape(s.name) << "\","
             << "\"virtualAddress\":" << s.virtualAddress << ","
             << "\"virtualSize\":" << s.virtualSize << ","
             << "\"rawSize\":" << s.rawSize << ","
             << "\"rawOffset\":" << s.rawOffset
             << "}";
    }
    json << "],";

    if (info.error.empty()) {
        json << "\"error\":null";
    } else {
        json << "\"error\":\"" << jsonEscape(info.error) << "\"";
    }
    json << "}";
    return json.str();
}

} // namespace

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_wintranslate_arm_native_NativeBridge_inspectPe(JNIEnv* env, jobject /*thiz*/, jbyteArray data) {
    jsize length = env->GetArrayLength(data);
    std::vector<uint8_t> buffer(static_cast<size_t>(length));
    if (length > 0) {
        env->GetByteArrayRegion(data, 0, length, reinterpret_cast<jbyte*>(buffer.data()));
    }

    pe::PeInfo info = pe::parseHeaders(buffer.data(), buffer.size());
    std::string json = toJson(info);
    return env->NewStringUTF(json.c_str());
}

JNIEXPORT jint JNICALL
Java_com_wintranslate_arm_native_NativeBridge_engineInitialize(JNIEnv* /*env*/, jobject /*thiz*/) {
    engine::EngineConfig config;
    engine::EngineResult result = g_engine.initialize(config);
    return static_cast<jint>(result);
}

JNIEXPORT jint JNICALL
Java_com_wintranslate_arm_native_NativeBridge_engineExecute(JNIEnv* env, jobject /*thiz*/, jstring binaryPath) {
    const char* pathChars = env->GetStringUTFChars(binaryPath, nullptr);
    std::string path(pathChars != nullptr ? pathChars : "");
    if (pathChars != nullptr) {
        env->ReleaseStringUTFChars(binaryPath, pathChars);
    }

    engine::EngineResult result = g_engine.execute(path);
    return static_cast<jint>(result);
}

} // extern "C"
