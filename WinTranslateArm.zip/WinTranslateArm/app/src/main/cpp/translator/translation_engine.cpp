#include "translation_engine.h"
#include "../common/log.h"

namespace engine {

EngineResult StubTranslationEngine::initialize(const EngineConfig& config) {
    config_ = config;
    initialized_ = true;
    LOGI("StubTranslationEngine initialized (mode=%d, cacheSizeBytes=%llu, diskCache=%d)",
         static_cast<int>(config_.mode),
         static_cast<unsigned long long>(config_.cacheSizeBytes),
         config_.diskCacheEnabled ? 1 : 0);
    return EngineResult::Ok;
}

bool StubTranslationEngine::canExecute(int /*architecture*/) const {
    // No translation backend is wired in yet, so nothing can actually
    // execute. See ARCHITECTURE.md for the integration plan (Box64 / FEX-Emu).
    return false;
}

EngineResult StubTranslationEngine::execute(const std::string& binaryPath) {
    LOGE("execute(%s) called, but no translation backend is integrated yet", binaryPath.c_str());
    return EngineResult::NotImplemented;
}

EngineResult StubTranslationEngine::terminate(int /*pid*/) {
    return EngineResult::Ok;
}

EngineResult StubTranslationEngine::shutdown() {
    initialized_ = false;
    return EngineResult::Ok;
}

} // namespace engine
