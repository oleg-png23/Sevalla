#pragma once

#include <cstdint>
#include <string>

namespace engine {

enum class TranslationMode {
    Fast,
    Balanced,
    Compatibility
};

struct EngineConfig {
    TranslationMode mode = TranslationMode::Balanced;
    uint64_t cacheSizeBytes = 32ull * 1024 * 1024;
    bool diskCacheEnabled = true;
};

// Mirrors the Kotlin-side result codes documented in TranslationEngine.kt.
enum class EngineResult : int {
    Ok = 0,
    NotInitialized = -1,
    UnsupportedArchitecture = -2,
    InvalidExecutable = -3,
    NotImplemented = -100
};

// Abstract interface for an x86/x86_64 -> ARM64 CPU translation backend.
// No implementation of this interface in this project actually translates
// or executes foreign-architecture code -- see StubTranslationEngine below
// and ARCHITECTURE.md for why, and what a real backend would need.
class ITranslationEngine {
public:
    virtual ~ITranslationEngine() = default;

    virtual EngineResult initialize(const EngineConfig& config) = 0;
    virtual bool canExecute(int architecture) const = 0;
    virtual EngineResult execute(const std::string& binaryPath) = 0;
    virtual EngineResult terminate(int pid) = 0;
    virtual EngineResult shutdown() = 0;
};

// Honest stub: tracks configuration/initialization state correctly, but
// never claims to execute translated code. execute() always returns
// NotImplemented. This is intentional -- see ARCHITECTURE.md.
class StubTranslationEngine : public ITranslationEngine {
public:
    EngineResult initialize(const EngineConfig& config) override;
    bool canExecute(int architecture) const override;
    EngineResult execute(const std::string& binaryPath) override;
    EngineResult terminate(int pid) override;
    EngineResult shutdown() override;

private:
    bool initialized_ = false;
    EngineConfig config_;
};

} // namespace engine
