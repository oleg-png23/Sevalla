-keep class com.wintranslate.arm.native.NativeBridge {
    native <methods>;
}
-keepclasseswithmembernames class * {
    native <methods>;
}
