package app.prism

import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class Mode(val hint: String) {
    Chat("Primary model only"),
    Fusion("All models answer in parallel; the primary fuses the best parts"),
    Advisor("Primary drafts, the second model critiques, primary revises"),
    Supervisor("Primary splits the task, the other models work it, primary combines")
}

const val SYS = "You are a helpful assistant. For anything visual or interactive (apps, charts, games, pages), reply with one complete self-contained HTML file in a single ```html block so it opens as an artifact."
private const val FUSE = "Several AI models answered the same question. Merge their best points into one accurate, well-organized answer. Resolve conflicts, drop errors, and don't mention the models."
private const val ADVISE = "You are a senior advisor. Review the draft answer: list factual errors, gaps and concrete improvements. Be brief."
private const val PLAN = "You are a supervisor. Split the user's task into 2-5 independent subtasks. Reply with ONLY a JSON array of strings."
private const val SYNTH = "You are the supervisor. Combine the workers' results into one final, coherent answer for the user."

typealias Key = Pair<Ep, String> // endpoint + decrypted API key

object Engine {
    private val http = OkHttpClient.Builder().readTimeout(180, TimeUnit.SECONDS).build()
    private val JSON = "application/json".toMediaType()

    /** One request to an Anthropic-style or OpenAI-compatible endpoint. */
    private suspend fun call(e: Key, system: String, msgs: List<Msg>): String = withContext(Dispatchers.IO) {
        val (ep, key) = e
        val anthropic = ep.kind == "anthropic"
        val turns = msgs.map { JSONObject().put("role", it.role).put("content", it.text) }
        val body = JSONObject().put("model", ep.model).apply {
            if (anthropic) put("max_tokens", 4096).put("system", system).put("messages", JSONArray(turns))
            else put("messages", JSONArray(listOf(JSONObject().put("role", "system").put("content", system)) + turns))
        }
        val req = Request.Builder()
            .url(ep.baseUrl + if (anthropic) "/v1/messages" else "/chat/completions")
            .apply { if (anthropic) header("x-api-key", key).header("anthropic-version", "2023-06-01") else header("Authorization", "Bearer $key") }
            .post(body.toString().toRequestBody(JSON)).build()
        http.newCall(req).execute().use { r ->
            val t = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("${ep.label}: HTTP ${r.code} ${t.take(300)}")
            val j = JSONObject(t)
            if (anthropic) j.getJSONArray("content").let { c -> (0 until c.length()).joinToString("") { c.getJSONObject(it).optString("text") } }
            else j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
        }
    }

    /** Web search via Tavily; results are injected into the system prompt. */
    suspend fun web(q: String, key: String): String = withContext(Dispatchers.IO) {
        require(key.isNotBlank()) { "Add a Tavily key in Settings to use Web" }
        val req = Request.Builder().url("https://api.tavily.com/search").header("Authorization", "Bearer $key")
            .post(JSONObject().put("query", q.take(400)).put("max_results", 5).toString().toRequestBody(JSON)).build()
        http.newCall(req).execute().use { r ->
            val t = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("Web search: HTTP ${r.code}")
            val a = JSONObject(t).optJSONArray("results") ?: JSONArray()
            (0 until a.length()).joinToString("\n\n") { i ->
                a.getJSONObject(i).let { "[${i + 1}] ${it.optString("title")} (${it.optString("url")})\n${it.optString("content")}" }
            }
        }
    }

    /** eps[0] = primary (fuser / supervisor / drafter), eps[1] = advisor, the rest = panel / workers. */
    suspend fun run(mode: Mode, hist: List<Msg>, sys: String, eps: List<Key>, status: (String) -> Unit): String = coroutineScope {
        val q = hist.last().text
        suspend fun ask(e: Key, s: String, m: List<Msg> = hist) = call(e, s, m)
        suspend fun safe(e: Key, s: String, m: List<Msg>) = runCatching { call(e, s, m) }.getOrElse { "(failed: ${it.message})" }
        when (mode) {
            Mode.Chat -> ask(eps[0], sys)
            Mode.Fusion -> {
                status("Asking ${eps.size} models…")
                val drafts = eps.map { async { safe(it, sys, hist) } }.awaitAll()
                status("Fusing…")
                ask(eps[0], FUSE, listOf(Msg("user", "Question:\n$q\n\n" + drafts.indices.joinToString("\n\n") { "### ${eps[it].first.label}\n${drafts[it]}" })))
            }
            Mode.Advisor -> {
                status("Drafting…")
                val draft = ask(eps[0], sys)
                status("Advisor reviewing…")
                val review = ask(eps.getOrElse(1) { eps[0] }, ADVISE, listOf(Msg("user", "Question:\n$q\n\nDraft:\n$draft")))
                status("Revising…")
                ask(eps[0], sys, hist + Msg("assistant", draft) + Msg("user", "An advisor reviewed your draft:\n$review\n\nWrite the final improved answer."))
            }
            Mode.Supervisor -> {
                val workers = eps.drop(1).ifEmpty { eps }
                status("Planning…")
                val plan = ask(eps[0], PLAN, listOf(Msg("user", q)))
                val arr = runCatching { JSONArray("[" + plan.substringAfter('[').substringBeforeLast(']') + "]") }.getOrNull()
                val subs = arr?.let { a -> (0 until a.length()).map { a.optString(it) } }.orEmpty().take(5).ifEmpty { listOf(q) }
                status("Running ${subs.size} workers…")
                val out = subs.mapIndexed { i, t ->
                    async { safe(workers[i % workers.size], sys, listOf(Msg("user", "Overall goal: $q\n\nYour subtask: $t"))) }
                }.awaitAll()
                status("Combining…")
                ask(eps[0], SYNTH, listOf(Msg("user", "Goal: $q\n\n" + subs.indices.joinToString("\n\n") { "Subtask: ${subs[it]}\nResult: ${out[it]}" })))
            }
        }
    }
}
