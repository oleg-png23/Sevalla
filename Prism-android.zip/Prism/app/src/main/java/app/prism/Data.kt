package app.prism

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Ep(val id: String, val label: String, val kind: String, val baseUrl: String, val model: String, val on: Boolean = true)
data class Msg(val role: String, val text: String)

/** Endpoints live in SharedPreferences; API keys are AES-GCM encrypted with an Android Keystore key. */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("prism", Context.MODE_PRIVATE)

    private fun aes(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("prism", null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder("prism", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()
        )
        return g.generateKey()
    }

    fun putKey(c: Context, id: String, key: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, aes()) }
        val out = cipher.iv + cipher.doFinal(key.toByteArray())
        sp(c).edit().putString("k_$id", Base64.encodeToString(out, Base64.NO_WRAP)).apply()
    }

    fun getKey(c: Context, id: String): String {
        val b = Base64.decode(sp(c).getString("k_$id", null) ?: return "", Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, aes(), GCMParameterSpec(128, b, 0, 12)) }
        return String(cipher.doFinal(b, 12, b.size - 12))
    }

    fun has(c: Context, id: String) = sp(c).contains("k_$id")
    fun dropKey(c: Context, id: String) = sp(c).edit().remove("k_$id").apply()

    fun loadEps(c: Context): List<Ep> {
        val a = JSONArray(sp(c).getString("eps", "[]"))
        return (0 until a.length()).map {
            a.getJSONObject(it).run { Ep(getString("id"), getString("label"), getString("kind"), getString("baseUrl"), getString("model"), optBoolean("on", true)) }
        }
    }

    fun saveEps(c: Context, eps: List<Ep>) {
        val a = JSONArray()
        eps.forEach { a.put(JSONObject().put("id", it.id).put("label", it.label).put("kind", it.kind).put("baseUrl", it.baseUrl).put("model", it.model).put("on", it.on)) }
        sp(c).edit().putString("eps", a.toString()).apply()
    }
}
