@file:OptIn(ExperimentalMaterial3Api::class)

package app.prism

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            val ctx = LocalContext.current
            val scheme = when {
                Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { App() } }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val eps = remember { mutableStateListOf<Ep>().apply { addAll(Store.loadEps(ctx)) } }
    val msgs = remember { mutableStateListOf<Msg>() }
    var mode by remember { mutableStateOf(Mode.Chat) }
    var web by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(eps.isEmpty()) }
    var artifact by remember { mutableStateOf<String?>(null) }
    val list = rememberLazyListState()

    fun send() {
        val q = input.trim()
        if (q.isEmpty() || busy) return
        val active = eps.filter { it.on }.map { it to Store.getKey(ctx, it.id) }
        if (active.isEmpty()) { settings = true; return }
        msgs += Msg("user", q); input = ""; busy = true
        scope.launch {
            val out = try {
                var sys = SYS
                if (web) {
                    status = "Searching the web…"
                    sys += "\n\nWeb results (cite as [n]):\n" + Engine.web(q, Store.getKey(ctx, "web"))
                }
                Engine.run(mode, msgs.toList(), sys, active) { status = it }
            } catch (e: Exception) { "Error: ${e.message}" }
            msgs += Msg("assistant", out); busy = false; status = ""
            list.animateScrollToItem(msgs.lastIndex)
        }
    }

    if (settings) {
        Settings(eps) { settings = false }
    } else {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Prism") }, actions = { IconButton({ settings = true }) { Icon(Icons.Default.Settings, "Settings") } }) },
            modifier = Modifier.imePadding()
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Mode.entries.forEach { FilterChip(mode == it, { mode = it }, { Text(it.name) }) }
                    FilterChip(web, { web = !web }, { Text("Web") })
                }
                Text(mode.hint, Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
                LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), list, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(msgs) { Bubble(it) { h -> artifact = h } }
                    if (busy) item { Text(status.ifEmpty { "Thinking…" }, style = MaterialTheme.typography.labelMedium) }
                }
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message") }, maxLines = 5)
                    Spacer(Modifier.width(8.dp))
                    Button(::send, enabled = !busy) { Text("Send") }
                }
            }
        }
    }
    artifact?.let { ArtifactDialog(it) { artifact = null } }
}

@Composable
fun Bubble(m: Msg, open: (String) -> Unit) {
    val mine = m.role == "user"
    val html = Regex("```html\\s*([\\s\\S]*?)```").find(m.text)?.groupValues?.get(1)
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        Surface(
            color = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = MaterialTheme.shapes.large
        ) { SelectionContainer { Text(m.text, Modifier.padding(12.dp)) } }
        if (html != null) TextButton({ open(html) }) { Text("Open artifact") }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ArtifactDialog(html: String, close: () -> Unit) {
    Dialog(close, DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.systemBarsPadding()) {
                TextButton(close) { Text("Close") }
                AndroidView({ c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                    }
                }, Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}

@Composable
fun Settings(eps: SnapshotStateList<Ep>, close: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = close)
    var kind by remember { mutableStateOf("openai") }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("https://api.openai.com/v1") }
    var model by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var webKey by remember { mutableStateOf("") }
    fun save() = Store.saveEps(ctx, eps.toList())
    val full = Modifier.fillMaxWidth()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Models and keys") }, actions = { TextButton(close) { Text("Done") } }) },
        modifier = Modifier.imePadding()
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("The first enabled model is the primary; the second is the advisor. Keys are encrypted on this device.", style = MaterialTheme.typography.bodySmall)
            val on = eps.filter { it.on }
            eps.forEachIndexed { i, e ->
                val role = when (e.id) { on.getOrNull(0)?.id -> " (primary)"; on.getOrNull(1)?.id -> " (advisor)"; else -> "" }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(e.label + role); Text(e.model, style = MaterialTheme.typography.bodySmall) }
                    if (i > 0) TextButton({ eps.add(i - 1, eps.removeAt(i)); save() }) { Text("Up") }
                    Switch(e.on, { eps[i] = e.copy(on = it); save() })
                    IconButton({ Store.dropKey(ctx, e.id); eps.removeAt(i); save() }) { Icon(Icons.Default.Delete, "Delete") }
                }
            }
            HorizontalDivider()
            Text("Add a model", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "Anthropic" to ("anthropic" to "https://api.anthropic.com"),
                    "OpenAI" to ("openai" to "https://api.openai.com/v1"),
                    "OpenRouter" to ("openai" to "https://openrouter.ai/api/v1"),
                    "Gemini" to ("openai" to "https://generativelanguage.googleapis.com/v1beta/openai"),
                    "Custom" to ("openai" to "")
                ).forEach { (n, p) -> AssistChip({ kind = p.first; url = p.second }, { Text(n) }) }
            }
            OutlinedTextField(name, { name = it }, full, label = { Text("Name (optional)") }, singleLine = true)
            OutlinedTextField(url, { url = it }, full, label = { Text("Base URL") }, singleLine = true)
            OutlinedTextField(model, { model = it }, full, label = { Text("Model ID") }, singleLine = true)
            OutlinedTextField(key, { key = it }, full, label = { Text("API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            Button({
                val id = UUID.randomUUID().toString()
                Store.putKey(ctx, id, key.trim())
                eps += Ep(id, name.ifBlank { model }.trim(), kind, url.trim().trimEnd('/'), model.trim())
                save(); name = ""; model = ""; key = ""
            }, enabled = url.isNotBlank() && model.isNotBlank() && key.isNotBlank()) { Text("Add model") }
            HorizontalDivider()
            Text("Web search", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(
                webKey, { webKey = it }, full,
                label = { Text(if (Store.has(ctx, "web")) "Tavily key saved; paste to replace" else "Tavily API key") },
                singleLine = true, visualTransformation = PasswordVisualTransformation()
            )
            Button({ Store.putKey(ctx, "web", webKey.trim()); webKey = "" }, enabled = webKey.isNotBlank()) { Text("Save web key") }
        }
    }
}
